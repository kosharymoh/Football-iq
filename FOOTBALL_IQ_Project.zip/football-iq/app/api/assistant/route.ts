import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const key = process.env.AI_API_KEY;
  if (!key) return NextResponse.json({
    error: "AI assistant is not configured yet.",
    detail: "Add AI_API_KEY, AI_BASE_URL and AI_MODEL to .env.local. The assistant will not invent football facts."
  }, { status: 503 });

  const body = await req.json().catch(() => ({}));
  const question = typeof body.question === "string" ? body.question.trim() : "";
  if (!question) return NextResponse.json({ error: "Enter a question first." }, { status: 400 });

  const base = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  try {
    const upstream = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        temperature: 0.25,
        messages: [
          { role: "system", content: "You are FOOTBALL IQ, a careful football analyst. Distinguish established facts, data-backed analysis, and speculation. Never invent statistics, injuries, transfers, lineups, or citations. If the user asks for current facts but no verified source data is supplied, clearly say you cannot verify them. Explain uncertainty." },
          { role: "user", content: question }
        ]
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return NextResponse.json({ error: "AI provider request failed.", detail: data.error?.message || `Provider status ${upstream.status}` }, { status: 502 });
    return NextResponse.json({ answer: data.choices?.[0]?.message?.content || "No answer was returned." });
  } catch {
    return NextResponse.json({ error: "Could not connect to the AI provider." }, { status: 502 });
  }
}