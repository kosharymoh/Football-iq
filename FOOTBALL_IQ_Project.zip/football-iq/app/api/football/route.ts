import { NextRequest, NextResponse } from "next/server";

const BASE = "https://api.football-data.org/v4";
const allowed = new Set(["competitions", "matches", "teams", "standings", "scorers"]);

export async function GET(req: NextRequest) {
  const token = process.env.FOOTBALL_DATA_TOKEN;
  const resource = req.nextUrl.searchParams.get("resource") || "matches";
  const id = req.nextUrl.searchParams.get("id");
  const dateFrom = req.nextUrl.searchParams.get("dateFrom");
  const dateTo = req.nextUrl.searchParams.get("dateTo");
  const competition = req.nextUrl.searchParams.get("competition");

  if (!allowed.has(resource)) return NextResponse.json({ error: "Unsupported resource." }, { status: 400 });
  if (!token) return NextResponse.json({
    error: "Football data provider is not configured.",
    detail: "Add FOOTBALL_DATA_TOKEN to .env.local. No sample scores or statistics are substituted.",
    configured: false
  }, { status: 503 });

  let path = `/${resource}`;
  if (resource === "teams" && id) path = `/teams/${encodeURIComponent(id)}`;
  if (resource === "standings" && id) path = `/competitions/${encodeURIComponent(id)}/standings`;
  if (resource === "scorers" && id) path = `/competitions/${encodeURIComponent(id)}/scorers`;
  if (resource === "matches" && id) path = `/matches/${encodeURIComponent(id)}`;
  const params = new URLSearchParams();
  if (dateFrom) params.set("dateFrom", dateFrom);
  if (dateTo) params.set("dateTo", dateTo);
  if (competition && resource === "matches") params.set("competitions", competition);
  const url = `${BASE}${path}${params.size ? `?${params.toString()}` : ""}`;

  try {
    const response = await fetch(url, {
      headers: { "X-Auth-Token": token },
      next: { revalidate: 120 }
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) return NextResponse.json({
      error: "Football data provider returned an error.",
      detail: payload.message || `Provider status ${response.status}`,
      providerStatus: response.status
    }, { status: response.status });
    return NextResponse.json({ ...payload, configured: true, source: "football-data.org" });
  } catch {
    return NextResponse.json({ error: "Unable to reach the football data provider." }, { status: 502 });
  }
}